

clc
clear
close all
%%
for Function_name = 1:12
nPop = 30 ; % number of population
Max_iter = 500 ; % maximum number of iterations
dim = 10 ; % The value can be 10,20

%%  select function
% Function_name= 1 ; % function name： 1 - 12
[lb,ub,dim,fobj] = Get_Functions_cec2022(Function_name,dim);




%% MSDBO 
tic
[MSDBO_Best_score,MSDBO_Best_pos,MSDBO_cg_curve]=MSDBO(nPop,Max_iter,lb,ub,dim,fobj);
toc
display(['The best optimal value of the objective funciton found by MSDBO  for F' [num2str(Function_name)],' is: ', num2str(MSDBO_Best_score)]);
fprintf ('Best solution obtained by MSDBO: %s\n', num2str(MSDBO_Best_pos,'%e  '));
%% plot
% figure('Position',[400 200 300 250])
figure


semilogy(MSDBO_cg_curve,'y','Linewidth',2)

title(['CEC2022-F',num2str(Function_name), ' (Dim=' num2str(dim), ')'])
xlabel('Iteration');
ylabel(['Best score F' num2str(Function_name) ]);
axis tight
grid on
box on
set(gca,'color','none')
legend('MSDBO')
pause(1)
end
